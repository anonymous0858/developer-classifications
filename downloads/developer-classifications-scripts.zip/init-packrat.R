## bootstrap packrat
cat("Bootstrapping packrat", "\n")
packrat::restore(prompt = FALSE)

