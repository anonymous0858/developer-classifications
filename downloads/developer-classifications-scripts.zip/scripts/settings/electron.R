GROUND_TRUTHS = c(
  # "all_data",
  "issues",
  "issuesInclBorderline",
  "committer"#,
  # "omc",
  # "otc",
  # "former_gt_all",
  # "former_gt_timed"
)

COMPUTE_GT_SET = c(
  "CoreClassification",
  # "LOC",
  # "CC",
  # "CC_LOC",
  # "Union",
  # "Intersect",
  "Other_GT"
)

get_available_gts <- function(){
  available_gts = c(
                  #  "all_data",
                    "issues",
                    "issuesInclBorderline",
                    "committer"#,
                  #  "omc",
                  #  "otc",
                  #  "former_gt_all",
                  #  "former_gt_timed"
                   )
  return(available_gts)
}

review_committer <- function() {

  main_table <- list()
  main_table["committer"] = list(unique(c(
    # Source: Electron Governance https://github.com/electron/governance/tree/d44d530600cfd26c719b6746fe042c5bbcf31378
    # Date: 2020-11
    "John Kleinschmidt",
    "Shelley Vohr",
    "Andy Locascio",
    "Charles Kerr",
    "Jeremy Apthorp", # aka Jeremy Rose
    "VerteDinde", #Keeley Hammond
    "Milan Burda",
    "Samuel Attard",
    "Will Anderson",
    "Deepak Mohan",
    "Sofia Nguy",
    "Cheng Zhao",
    "mlaurencin", #Michaela Laurencin
    #"Pedro Pontes", #Security
    #"Steve Barbaro", #Security
    "Aleksei Kuzmin", #Alexey Kuzmin
    "Jacob Groundwater",
    "Anton Molleda", # not found
    "Felix Rieseberg"

  )))

  return(main_table)
}

filter_issues <- function(project.data) {
  project.data$set.issues(filter(project.data$get.issues(),
                                 author.name != "GitHub"
                                 ))
  return(project.data)
}
