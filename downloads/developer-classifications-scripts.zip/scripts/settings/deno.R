GROUND_TRUTHS = c(
  # "all_data",
  "issues",
  "issuesInclBorderline"#,
  # "committer"#,
  # "omc",
  # "otc",
  # "former_gt_all",
  # "former_gt_timed"
)

COMPUTE_GT_SET = c(
  "CoreClassification"#,
  # "LOC",
  # "CC",
  # "CC_LOC",
  # "Union",
  # "Intersect",
  # "Other_GT"
)

get_available_gts <- function(){
  available_gts = c(
                  #  "all_data",
                    "issues",
                    "issuesInclBorderline"#,
                  #  "committer",
                  #  "omc",
                  #  "otc",
                  #  "former_gt_all",
                  #  "former_gt_timed"
                   )
  return(available_gts)
}

review_committer <- function() {

  main_table <- list()
  main_table["committer"] = list(unique(c(
    # Add committers' names
  )))

  return(main_table)
}

filter_issues <- function(project.data) {
  project.data$set.issues(filter(project.data$get.issues(),
                                 author.name != "GitHub"
                                 ))
  return(project.data)
}
