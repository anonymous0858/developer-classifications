AUTHOR.RELATION <- list()
AUTHOR.RELATION[[1]] <- "cochange"
AUTHOR.RELATION[[2]] <- "issue"
#AUTHOR.RELATION[[3]] <- "mail"
AUTHOR.RELATION[[3]] <- c("cochange", "issue")
#AUTHOR.RELATION[[5]] <- c("cochange", "mail")
#AUTHOR.RELATION[[6]] <- c("issue", "mail")
#AUTHOR.RELATION[[7]] <- c("cochange", "issue", "mail")

SIMPLIFY.DIRECTED <- c( # comment out, which combination of simplify and directed are currently not needed
  "FF",
  "FT",
  "TF",
  "TT"
)

CLASSIFICATION = c( # comment out, which classification metrics are currently not needed
  "network_degree",
  "network_eigen",
  "network_hierarchy",
  "commit_count",
  "loc_count"
)

METRICS = c(
  "Jaccard",
  "Overlap",
  "Intersect",
  "Union",
  "Precision",
  "Recall",
  "F1",
  # "Balanced Accuracy",
  "Specificity"
)

PLOTTING = c(
  "network_degree",
  "network_eigen",
  "network_hierarchy"#,
  # "commit_count",
  # "loc_count"
)

good <- c(
  "added_to_project",
  "converted_note_to_issue",
  "deployed",
  "deployment_environment_changed",
  "locked",
  "merged",
  "moved_columns_in_project",
  "pinned",
  "removed_from_project",
  "review_dismissed",
  #"review_request_removed",
  "transferred",
  "unlocked",
  "unpinned",
  "user_blocked"
)

borderline <- c(
  "assigned",
  "demilestoned",
  "labeled",
  "marked_as_duplicate",
  "milestoned",
  #"review_requested",
  "unassigned",
  "unlabeled",
  "unmarked_as_duplicate"
)

COLUMN_NAMES = c(
  "start_date",
  "simplify.directed",
  "Ground_Truth",
  "similarity metric",
  "compute_set",
  "nd_cochange",
  "ne_cochange",
  "nh_cochange",
  "cc_cochange",
  "loc_cochange",
  "nd_issue",
  "ne_issue",
  "nh_issue",
  "cc_issue",
  "loc_issue",
  "nd_mail",
  "ne_mail",
  "nh_mail",
  "cc_mail",
  "loc_mail",
  "nd_co_is",
  "ne_co_is",
  "nh_co_is",
  "cc_co_is",
  "loc_co_is",
  "nd_co_ma",
  "ne_co_ma",
  "nh_co_ma",
  "cc_co_ma",
  "loc_co_ma",
  "nd_is_ma",
  "ne_is_ma",
  "nh_is_ma",
  "cc_is_ma",
  "loc_is_ma",
  "nd_co_is_ma",
  "ne_co_is_ma",
  "nh_co_is_ma",
  "cc_co_is_ma",
  "loc_co_is_ma"
)

COLUMN_NAMES_PERIPHERAL = c(
  "nd_cochange_p",
  "ne_cochange_p",
  "nh_cochange_p",
  "cc_cochange_p",
  "loc_cochange_p",
  "nd_issue_p",
  "ne_issue_p",
  "nh_issue_p",
  "cc_issue_p",
  "loc_issue_p",
  "nd_mail_p",
  "ne_mail_p",
  "nh_mail_p",
  "cc_mail_p",
  "loc_mail_p",
  "nd_co_is_p",
  "ne_co_is_p",
  "nh_co_is_p",
  "cc_co_is_p",
  "loc_co_is_p",
  "nd_co_ma_p",
  "ne_co_ma_p",
  "nh_co_ma_p",
  "cc_co_ma_p",
  "loc_co_ma_p",
  "nd_is_ma_p",
  "ne_is_ma_p",
  "nh_is_ma_p",
  "cc_is_ma_p",
  "loc_is_ma_p",
  "nd_co_is_ma_p",
  "ne_co_is_ma_p",
  "nh_co_is_ma_p",
  "cc_co_is_ma_p",
  "loc_co_is_ma_p"
)
