GROUND_TRUTHS = c(
  # "all_data",
  "issues",
  "issuesInclBorderline",
  "committer"#,
  # "omc",
  # "otc",
  # "former_gt_all",
  # "former_gt_timed"
)

COMPUTE_GT_SET = c(
  "CoreClassification",
  # "LOC",
  # "CC",
  # "CC_LOC",
  # "Union",
  # "Intersect",
  "Other_GT"
)

get_available_gts <- function(){
  available_gts = c(
                  #  "all_data",
                    "issues",
                    "issuesInclBorderline",
                    "committer"#,
                  #  "omc",
                  #  "otc",
                  #  "former_gt_all",
                  #  "former_gt_timed"
                   )
  return(available_gts)
}

review_committer <- function() {

  main_table <- list()
  main_table["committer"] = list(unique(c(
    # Source: https://www.openssl.org/community/committers.html (2019-11-21)
    "Ben Kaduk", # Benjamin Kaduk
    "Bernd Edlinger",
    "David Benjamin",
    "Dr. David von Oheimb", # David von Oheimb
    "Dmitry Belyavsky", # Dmitry Belyavskiy
    "Kurt Roeckx",
    "Mark J. Cox",
    "Matt Caswell",
    "Dr. Matthias St. Pierre", # Matthias St. Pierre
    "Nicola Tuveri",
    "Patrick Steuer",
    "Pauli", # Paul Dale
    "Paul Yang",
    "Richard Levitte",
    "Shane Lontis",
    "Tim Hudson",
    "Tomas Mraz",
    "Viktor Dukhovni"#,
    #from here start the alumni
    # "Steven Henson", # Stephen Henson
    # "Lutz Jänicke",
    # "Emilia Käsper", # Emilia Kasper
    # "Ben Laurie",
    # "Steve Marquess",
    # "Bodo Möller",
    # "Andy Polyakov",
    # "Rich Salz",
    # "Geoffrey Thorpe" #, Geoff Thorpe
  )))

  return(main_table)
}

review_omc <- function() {

  main_table <- list()
  main_table <- c(main_table, issue_reviewed = list(unique(c(
    "Kurt Roeckx",
    "Mark J. Cox",
    "Matt Caswell",
    "Pauli", # Paul Dale
    "Richard Levitte",
    "Tim Hudson",
    "Viktor Dukhovni"
  ))))

  return(main_table)
}

review_otc <- function() {

  main_table <- list()
  main_table <- c(main_table, issue_reviewed = list(unique(c(
    "Kurt Roeckx",
    "Mark J. Cox",
    "Matt Caswell",
    "Dr. Matthias St. Pierre", # Matthias St. Pierre
    "Nicola Tuveri",
    "Pauli", # Paul Dale,
    "Richard Levitte",
    "Shane Lontis",
    "Tim Hudson",
    "Tomas Mraz",
    "Viktor Dukhovni"
  ))))

  return(Sort(main_table))
}

all_gt <- function() {
  all <- list()
  all <- c(all, committer = review_committer())
  all <- c(all, omc = review_omc())
  all <- c(all, otc = review_otc())

  return(all)
}

filter_issues <- function(project.data) {
  project.data$set.issues(filter(project.data$get.issues(),
                                 author.name != "dependabotbot"
                                 & author.name != "github-actionsbot"
                                 & author.name != "travis-cibot"
                                 & author.name != "openssl-machine"
                                 ))
  return(project.data)
}
