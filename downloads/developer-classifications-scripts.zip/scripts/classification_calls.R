network_degree <- function(main_table, network, relation, project.configuration, name, case){
  project.name <- paste(project.configuration$get.entry("repo"), ANALYSIS, sep="_")

  ## ANALYSIS

  # write the data to a file which denotes which developers are core and which are peripheral per type of evaluation
  # read out a data frame based on the evaluation

  network_evaluation = get.author.class.by.type(network = network, type = "network.degree")
  core <- list(network_evaluation$core$author.name)
  per <- list(network_evaluation$peripheral$author.name)

  data.frame.core = network_evaluation$core
  if (nrow(data.frame.core) > 0) {
    data.frame.core[["classification"]] = "core"
  }
  data.frame.peripheral = network_evaluation$peripheral
  if (nrow(data.frame.peripheral) > 0) {
    data.frame.peripheral[["classification"]] = "peripheral"
  }
  data.frame.all = rbind(data.frame.core, data.frame.peripheral)
  if (nrow(data.frame.all) > 0) {
    colnames(data.frame.all) = c("author.name", paste("degree", paste0(relation, collapse = "-"), sep = "_"),
                                 paste("classification", "degree", paste0(relation, collapse = "-"), sep = "_"))
    data.frame.all[["range"]] = name
    data.frame.all[["project"]] = CASESTUDY
    data.frame.all[["simplified.directed"]] = case
    data.frame.all = data.frame.all[, c("author.name", "project", "range", "simplified.directed", paste("degree", paste0(relation, collapse = "-"), sep = "_"),
                                        paste("classification", "degree", paste0(relation, collapse = "-"), sep = "_")) ]
  }

  ifelse(all(relation == "cochange"), main_table <- c(main_table, nd_cochange = core, nd_cochange_p = per),
         ifelse(all(relation == "issue"), main_table <- c(main_table, nd_issue = core, nd_issue_p = per),
                ifelse(all(relation == "mail"), main_table <- c(main_table, nd_mail = core, nd_mail_p = per),
                       ifelse(all(relation == c("cochange", "issue")), main_table <- c(main_table, nd_co_is = core, nd_co_is_p = per),
                              ifelse(all(relation == c("cochange", "mail")), main_table <- c(main_table, nd_co_ma = core, nd_co_ma_p = per),
                                     ifelse(all(relation == c("issue", "mail")), main_table <- c(main_table, nd_is_ma = core, nd_is_ma_p = per),
                                            ifelse(all(relation == c("cochange", "issue", "mail")), main_table <- c(main_table, nd_co_is_ma = core, nd_co_is_ma_p = per),
                                                   "default"
                                            )))))))

  return(list(data.frame.all, main_table))
}

network_eigen <- function(main_table, network, relation, project.configuration, name, case) {
  # network.configuration <- NetworkConf$new()
  project.name <- paste(project.configuration$get.entry("repo"), ANALYSIS, sep="_")

  ## ANALYSIS

  # write the data to a file which denotes which developers are core and which are peripheral per type of evaluation
  # read out a data frame based on the evaluation

  network_evaluation = get.author.class.by.type(network = network, type = "network.eigen")
  core <- list(network_evaluation$core$author.name)
  per <- list(network_evaluation$peripheral$author.name)

  data.frame.core = network_evaluation$core
  if (nrow(data.frame.core) > 0) {
    data.frame.core[["classification"]] = "core"
  }
  data.frame.peripheral = network_evaluation$peripheral
  if (nrow(data.frame.peripheral) > 0) {
    data.frame.peripheral[["classification"]] = "peripheral"
  }
  data.frame.all = rbind(data.frame.core, data.frame.peripheral)
  if (nrow(data.frame.all) > 0) {
    colnames(data.frame.all) = c("author.name", paste("eigen", paste0(relation, collapse = "-"), sep = "_"),
                                 paste("classification", "eigen", paste0(relation, collapse = "-"), sep = "_"))
    data.frame.all[["range"]] = name
    data.frame.all[["project"]] = CASESTUDY
    data.frame.all[["simplified.directed"]] = case
    data.frame.all = data.frame.all[, c("author.name", "project", "range", "simplified.directed", paste("eigen", paste0(relation, collapse = "-"), sep = "_"),
                                        paste("classification", "eigen", paste0(relation, collapse = "-"), sep = "_")) ]
  }

  ifelse(all(relation == "cochange"), main_table <- c(main_table, ne_cochange = core, ne_cochange_p = per),
         ifelse(all(relation == "issue"), main_table <- c(main_table, ne_issue = core, ne_issue_p = per),
                ifelse(all(relation == "mail"), main_table <- c(main_table, ne_mail = core, ne_mail_p = per),
                       ifelse(all(relation == c("cochange", "issue")), main_table <- c(main_table, ne_co_is = core, ne_co_is_p = per),
                              ifelse(all(relation == c("cochange", "mail")), main_table <- c(main_table, ne_co_ma = core, ne_co_ma_p = per),
                                     ifelse(all(relation == c("issue", "mail")), main_table <- c(main_table, ne_is_ma = core, ne_is_ma_p = per),
                                            ifelse(all(relation == c("cochange", "issue", "mail")), main_table <- c(main_table, ne_co_is_ma = core, ne_co_is_ma_p = per),
                                                   "default"
                                            )))))))

  return(list(data.frame.all, main_table))
}

network_hierarchy <- function(main_table, network, relation, project.configuration, name, case) {
  # network.configuration <- NetworkConf$new()
  project.name <- paste(project.configuration$get.entry("repo"), ANALYSIS, sep="_")

  ## ANALYSIS

  # write the data to a file which denotes which developers are core and which are peripheral per type of evaluation
  # read out a data frame based on the evaluation
  network_evaluation = get.author.class.by.type(network = network, type = "network.hierarchy")
  core <- list(network_evaluation$core$author.name)
  per <- list(network_evaluation$peripheral$author.name)

  data.frame.core = network_evaluation$core
  if (nrow(data.frame.core) > 0) {
    data.frame.core[["classification"]] = "core"
  }
  data.frame.peripheral = network_evaluation$peripheral
  if (nrow(data.frame.peripheral) > 0) {
    data.frame.peripheral[["classification"]] = "peripheral"
  }
  data.frame.all = rbind(data.frame.core, data.frame.peripheral)
  if (nrow(data.frame.all) > 0) {
    colnames(data.frame.all) = c("author.name", paste("hierarchy", paste0(relation, collapse = "-"), sep = "_"),
                                 paste("classification", "hierarchy", paste0(relation, collapse = "-"), sep = "_"))
    data.frame.all[["range"]] = name
    data.frame.all[["project"]] = CASESTUDY
    data.frame.all[["simplified.directed"]] = case
    data.frame.all = data.frame.all[, c("author.name", "project", "range", "simplified.directed", paste("hierarchy", paste0(relation, collapse = "-"), sep = "_"),
                                        paste("classification", "hierarchy", paste0(relation, collapse = "-"), sep = "_")) ]
  }

  ifelse(all(relation == "cochange"), main_table <- c(main_table, nh_cochange = core, nh_cochange_p = per),
         ifelse(all(relation == "issue"), main_table <- c(main_table, nh_issue = core, nh_issue_p = per),
                ifelse(all(relation == "mail"), main_table <- c(main_table, nh_mail = core, nh_mail_p = per),
                       ifelse(all(relation == c("cochange", "issue")), main_table <- c(main_table, nh_co_is = core, nh_co_is_p = per),
                              ifelse(all(relation == c("cochange", "mail")), main_table <- c(main_table, nh_co_ma = core, nh_co_ma_p = per),
                                     ifelse(all(relation == c("issue", "mail")), main_table <- c(main_table, nh_is_ma = core, nh_is_ma_p = per),
                                            ifelse(all(relation == c("cochange", "issue", "mail")), main_table <- c(main_table, nh_co_is_ma = core, nh_co_is_ma_p = per),
                                                   "default"
                                            )))))))
  return(list(data.frame.all, main_table))
}

commit_count <- function(main_table, network, relation, project.configuration, project.data, name, case) {
  # network.configuration <- NetworkConf$new()
  project.name <- paste(project.configuration$get.entry("repo"), ANALYSIS, sep="_")

  ## ANALYSIS

  # write the data to a file which denotes which developers are core and which are peripheral per type of evaluation
  # read out a data frame based on the evaluation

  network_evaluation = get.author.class.by.type(proj.data = project.data, type = "commit.count")
  core <- list(network_evaluation$core$author.name)
  per <- list(network_evaluation$peripheral$author.name)


  data.frame.core = network_evaluation$core
  if (nrow(data.frame.core) > 0) {
    data.frame.core[["classification"]] = "core"
  }
  data.frame.peripheral = network_evaluation$peripheral
  if (nrow(data.frame.peripheral) > 0) {
    data.frame.peripheral[["classification"]] = "peripheral"
  }
  data.frame.all = rbind(data.frame.core, data.frame.peripheral)
  if (nrow(data.frame.all) > 0) {
    colnames(data.frame.all) = c("author.name", paste("commitcount", paste0(relation, collapse = "-"), sep = "_"),
                                 paste("classification", "commitcount", paste0(relation, collapse = "-"), sep = "_"))
    data.frame.all[["range"]] = name
    data.frame.all[["project"]] = CASESTUDY
    data.frame.all[["simplified.directed"]] = case
    data.frame.all = data.frame.all[, c("author.name", "project", "range", "simplified.directed", paste("commitcount", paste0(relation, collapse = "-"), sep = "_"),
                                        paste("classification", "commitcount", paste0(relation, collapse = "-"), sep = "_")) ]
  }

  ifelse(all(relation == "cochange"), main_table <- c(main_table, cc_cochange = core, cc_cochange_p = per),
         ifelse(all(relation == "issue"), main_table <- c(main_table, cc_issue = core, cc_issue_p = per),
                ifelse(all(relation == "mail"), main_table <- c(main_table, cc_mail = core, cc_mail_p = per),
                       ifelse(all(relation == c("cochange", "issue")), main_table <- c(main_table, cc_co_is = core, cc_co_is_p = per),
                              ifelse(all(relation == c("cochange", "mail")), main_table <- c(main_table, cc_co_ma = core, cc_co_ma_p = per),
                                     ifelse(all(relation == c("issue", "mail")), main_table <- c(main_table, cc_is_ma = core, cc_is_ma_p = per),
                                            ifelse(all(relation == c("cochange", "issue", "mail")), main_table <- c(main_table, cc_co_is_ma = core, cc_co_is_ma_p = per),
                                                   "default"
                                            )))))))
  return(list(data.frame.all, main_table))
}

loc_count <- function(main_table, network, relation, project.configuration, project.data, name, case) {
  # network.configuration <- NetworkConf$new()
  project.name <- paste(project.configuration$get.entry("repo"), ANALYSIS, sep="_")

  ## ANALYSIS

  # write the data to a file which denotes which developers are core and which are peripheral per type of evaluation
  # read out a data frame based on the evaluation

  network_evaluation = get.author.class.by.type(proj.data = project.data, type = "loc.count")
  core <- list(network_evaluation$core$author.name)
  per <- list(network_evaluation$peripheral$author.name)


  data.frame.core = network_evaluation$core
  if (nrow(data.frame.core) > 0) {
    data.frame.core[["classification"]] = "core"
  }
  data.frame.peripheral = network_evaluation$peripheral
  if (nrow(data.frame.peripheral) > 0) {
    data.frame.peripheral[["classification"]] = "peripheral"
  }
  data.frame.all = rbind(data.frame.core, data.frame.peripheral)
  if (nrow(data.frame.all) > 0) {
    colnames(data.frame.all) = c("author.name", paste("loccount", paste0(relation, collapse = "-"), sep = "_"),
                                 paste("classification", "loccount", paste0(relation, collapse = "-"), sep = "_"))
    data.frame.all[["range"]] = name
    data.frame.all[["project"]] = CASESTUDY
    data.frame.all[["simplified.directed"]] = case
    data.frame.all = data.frame.all[, c("author.name", "project", "range", "simplified.directed", paste("loccount", paste0(relation, collapse = "-"), sep = "_"),
                                        paste("classification", "loccount", paste0(relation, collapse = "-"), sep = "_")) ]
  }

  ifelse(all(relation == "cochange"), main_table <- c(main_table, loc_cochange = core, loc_cochange_p = per),
         ifelse(all(relation == "issue"), main_table <- c(main_table, loc_issue = core, loc_issue_p = per),
                ifelse(all(relation == "mail"), main_table <- c(main_table, loc_mail = core, loc_mail_p = per),
                       ifelse(all(relation == c("cochange", "issue")), main_table <- c(main_table, loc_co_is = core, loc_co_is_p = per),
                              ifelse(all(relation == c("cochange", "mail")), main_table <- c(main_table, loc_co_ma = core, loc_co_ma_p = per),
                                     ifelse(all(relation == c("issue", "mail")), main_table <- c(main_table, loc_is_ma = core, loc_is_ma_p = per),
                                            ifelse(all(relation == c("cochange", "issue", "mail")), main_table <- c(main_table, loc_co_is_ma = core, loc_co_is_ma_p = per),
                                                   "default"
                                            )))))))
  return(list(data.frame.all, main_table))
}
