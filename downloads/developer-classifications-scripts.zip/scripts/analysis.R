## Create a table of the similarities based on the people that the classification deemed core developers compared with the established ground truth.

# the similarity measures with which we will compare the different lists

## ANALYSIS

review_issue_events <- function(project.data, include.borderline.events = FALSE) {

  if (include.borderline.events) {
    selected_issue_events <- data.frame(subset(project.data$get.issues(), (
      event.name %in% good | event.name %in% borderline
    )))
  } else {
    selected_issue_events <- data.frame(subset(project.data$get.issues(), (
      event.name %in% good
    )))
  }

  selected_issue_events_per_author <- count(selected_issue_events, author.name, sort = TRUE)
  ir_name <- list(selected_issue_events_per_author$author.name)
  # ir_calls <- list(selected_issue_events_per_author$n)

  # delete all commits that requested changes and keep only the approved changes
  # selected_issue_events_per_author <- subset(selected_issue_events_per_author, event.info.1 != "changes_requested")
  # write.table(count(data.frame(selected_issue_events_per_author), author.name, sort = TRUE), paste(script.output.path, "/approved.txt", sep = ""))

  main_table <- list()
  main_table <- c(main_table, issue_reviewed = c(name = ir_name #,
                                                 # calls = ir_calls
  ))
  return(main_table)
}

create_gt_table <- function(project.data, ranged.data, file.name, path, case) {

  gt_table <- list()

  available_gts = get_available_gts()

  for (gt in available_gts) {
    if (gt == "all_data") {
      gt_table["all_data"] <- sort(review_issue_events(project.data = project.data))
    }
    if (gt == "issues") {
      gt_table["issues"] <- review_issue_events(project.data = ranged.data, include.borderline.events = FALSE)
    }
    if (gt == "issuesInclBorderline") {
      gt_table["issuesInclBorderline"] <- review_issue_events(project.data = ranged.data, include.borderline.events = TRUE)
    }
    if (gt == "committer") {
      gt_table["committer"] <- review_committer()
    }
    if (gt == "omc") {
      gt_table["omc"] <- sort(review_omc())
    }
    if (gt == "otc") {
      gt_table["otc"] <- sort(review_otc())
    }
    #if (gt == "former_gt_all") {
    #  gt_table["former_gt_all"] <- sort(review_gt(project.data = project.data))
    #}
    #if (gt == "former_gt_timed") {
    #  gt_table["former_gt_timed"] <- sort(review_gt(project.data = ranged.data))
    #}
  }

  pathing <- sprintf("%s/GT", path)

  dir.create(pathing, showWarnings = FALSE, recursive = TRUE)

  #saveRDS(gt_table, file = sprintf("%s/%s_%s.rds", pathing, case, file.name))
  saveRDS(gt_table, file = sprintf("%s/%s_%s.rds", pathing, DISCRETISATION.NAME, file.name))
}

determine.time.differences.between.events.that.require.write.permission <- function(issues, pathing, include.borderline.events = FALSE) {

  if (include.borderline.events) {
    selected_issue_events <- data.frame(subset(issues, (
      event.name %in% good | event.name %in% borderline
    )))
  } else {
    selected_issue_events <- data.frame(subset(issues, (
      event.name %in% good
    )))
  }

  developers.with.write.permission = unique(selected_issue_events[["author.name"]])

  differences.per.developer = lapply(developers.with.write.permission, data = selected_issue_events, FUN=function(dev, data) {
    dev.events = data[data[["author.name"]] == dev, ]
    special.event.timestamps = sort(unique(dev.events[["date"]]))
    differences.between.special.events = as.numeric(abs(difftime(head(special.event.timestamps, -1), tail(special.event.timestamps, -1), units = "secs")))
    return(differences.between.special.events)
  })
  names(differences.per.developer) = developers.with.write.permission

  result_string = "write"
  if (include.borderline.events) {
    result_string = "writeAndBorderline"
  }

  dir.create(pathing, showWarnings = FALSE, recursive = TRUE)
  saveRDS(differences.per.developer, file = sprintf("%s/differences_between_a_developers_%s_permission_events.rds", pathing, result_string))
}

create_truth_table <- function(path) {
  logging::loginfo("Start Truth Table")

  # set the correct path where the similarity table shall go and create it
  pathing <- sprintf("%s/similarity", path)
  dir.create(pathing, showWarnings = FALSE, recursive = TRUE)

  # create the path where the current network_output and Ground_Truth is saved and create a list of them
  read_in_GT <- sprintf("%s/GT", path)
  read_in_netw_output <- sprintf("%s/network_output", path)

  all_GT_files <- list.files(path = read_in_GT, pattern = "*\\.rds")

  # create the data.frame which will contain all similarity computations
  df <- data.frame(matrix(ncol = length(COLUMN_NAMES)))
  colnames(df) <- COLUMN_NAMES

  # create the data.frame which will contain developers of the ground truth who are not part of the classification
  gt_devs_not_part_of_classification <- data.frame(matrix(ncol = length(COLUMN_NAMES)))
  colnames(gt_devs_not_part_of_classification) = COLUMN_NAMES

  # create the data.frame which will contain the percentage of developers of the ground truth who are not part of the classification
  gt_relative_devs_not_part_of_classification <- data.frame(matrix(ncol = length(COLUMN_NAMES)))
  colnames(gt_relative_devs_not_part_of_classification) = COLUMN_NAMES

  # create the data.frame which will contain the size of the ground truth
  gt_size <- data.frame(matrix(ncol = length(COLUMN_NAMES)))
  colnames(gt_size) = COLUMN_NAMES

  # create the data.frame which will contain the size of the core-classified group
  core_size <- data.frame(matrix(ncol = length(COLUMN_NAMES)))
  colnames(core_size) = COLUMN_NAMES

  # create the data.frame which will contain the size of the peripheral-classified group
  peripheral_size <- data.frame(matrix(ncol = length(COLUMN_NAMES)))
  colnames(peripheral_size) = COLUMN_NAMES

  # iterate over all files of the Ground_Truth
  for (sd in SIMPLIFY.DIRECTED) {
    for (i in seq_along(all_GT_files)) {
      file = all_GT_files[[i]]

      #name = substr(file, 1, 10) # substr(file, 4, 13)
      start_date = substr(file, nchar(file)-13, nchar(file)-13 + 9)

      gt_table <-
        #readRDS(file = sprintf("%s/%s_%s.rds", read_in_GT, sd, name))
          readRDS(file = sprintf("%s/%s", read_in_GT, file)) #DISCRETISATION.NAME, name))

      netw_output <-
        readRDS(file = sprintf("%s/%s_%s", read_in_netw_output, sd, file)) #DISCRETISATION.NAME, name))

      for (gt in GROUND_TRUTHS) {

        # temporal smoothness assumption: if a developer was present in the previous GT file and is present in the subsequent GT file,
        # then we assume they should also belong to the current GT file (maybe not present for illness or holiday reasons)
        if ((gt == "issues" || gt == "issuesInclBorderline") && i > 1 && i < length(all_GT_files)) {
          previous_file = all_GT_files[[i-1]]
          previous_gt_table = readRDS(file = sprintf("%s/%s", read_in_GT, previous_file)) #DISCRETISATION.NAME, name))

          subsequent_file = all_GT_files[[i+1]]
          subsequent_gt_table = readRDS(file = sprintf("%s/%s", read_in_GT, subsequent_file)) #DISCRETISATION.NAME, name))

          # check who is in the previous AND subsequent GT
          gt_people_available_before_and_after = intersect(previous_gt_table[[gt]], subsequent_gt_table[[gt]])

          # determine which people are in previous AND subsequent GT but not in current GT
          gt_people_missing_now = setdiff(gt_people_available_before_and_after, gt_table[[gt]])
          logging::loginfo(sprintf("Add the following devs to the GT who have been present in GT previously and subsequently but not currently: %s (%s)",
                                   length(gt_people_missing_now), paste(gt_people_missing_now, collapse = ", ")))

          # add people present in both previous AND subsequent GT to the current GT
          gt_table[[gt]] = union(gt_table[[gt]], gt_people_available_before_and_after)
        }

        for (metric in METRICS) {

          for (compute_set in COMPUTE_GT_SET) {
            results <- analyze(data = netw_output,
                               gt_table = gt_table,
                               ground.truth = gt, start_date = start_date,
                               main_set = analyze_by_set(gt_table = gt_table,
                                                         netw_output = netw_output,
                                                         compute_set = compute_set,
                                                         ground.truth = gt
                               ),
                               sd = sd,
                               metric = metric,
                               compute_set = compute_set
            )

            df <- rbind(df, results[[1]])

            if (compute_set == "CoreClassification") {
              gt_devs_not_part_of_classification <- rbind(gt_devs_not_part_of_classification, results[[2]])
              gt_relative_devs_not_part_of_classification <- rbind(gt_relative_devs_not_part_of_classification, results[[3]])

              gt_size <- rbind(gt_size, results[[4]])
              core_size <- rbind(core_size, results[[5]])
              peripheral_size <- rbind(peripheral_size, results[[6]])
            }
          }
        }
      }
    }
  }
  df <- distinct(df[rowSums(is.na(df)) != ncol(df),])
  gt_devs_not_part_of_classification <- distinct(gt_devs_not_part_of_classification[rowSums(is.na(gt_devs_not_part_of_classification)) != ncol(gt_devs_not_part_of_classification),])
  gt_relative_devs_not_part_of_classification <- distinct(gt_relative_devs_not_part_of_classification[rowSums(is.na(gt_relative_devs_not_part_of_classification)) != ncol(gt_relative_devs_not_part_of_classification),])

  gt_size <- distinct(gt_size[rowSums(is.na(gt_size)) != ncol(gt_size),])
  core_size <- distinct(core_size[rowSums(is.na(core_size)) != ncol(core_size),])
  peripheral_size <- distinct(peripheral_size[rowSums(is.na(peripheral_size)) != ncol(peripheral_size),])


  saveRDS(df, file = sprintf("%s/Truth_table_computed.rds", pathing))
  saveRDS(gt_devs_not_part_of_classification, file = sprintf("%s/gt_devs_not_part_of_classification.rds", pathing))
  saveRDS(gt_relative_devs_not_part_of_classification, file = sprintf("%s/gt_relative_devs_not_part_of_classification.rds", pathing))

  saveRDS(gt_size, file = sprintf("%s/gt_size.rds", pathing))
  saveRDS(core_size, file = sprintf("%s/core_size.rds", pathing))
  saveRDS(peripheral_size, file = sprintf("%s/peripheral_size.rds", pathing))
}

analyze <-function(data,
           gt_table,
           ground.truth,
           start_date,
           main_set,
           sd,
           metric,
           compute_set) {

    df <- data.frame(matrix(ncol = length(COLUMN_NAMES)))
    colnames(df) <- COLUMN_NAMES

    gt_devs_not_part_of_classification <- data.frame(matrix(ncol = length(COLUMN_NAMES)))
    colnames(gt_devs_not_part_of_classification) = COLUMN_NAMES

    gt_relative_devs_not_part_of_classification <- data.frame(matrix(ncol = length(COLUMN_NAMES)))
    colnames(gt_relative_devs_not_part_of_classification) = COLUMN_NAMES

    gt_size <- data.frame(matrix(ncol = length(COLUMN_NAMES)))
    colnames(gt_size) = COLUMN_NAMES

    core_size <- data.frame(matrix(ncol = length(COLUMN_NAMES)))
    colnames(core_size) = COLUMN_NAMES

    peripheral_size <- data.frame(matrix(ncol = length(COLUMN_NAMES)))
    colnames(peripheral_size) = COLUMN_NAMES

    df_peripheral <- data[grepl("_p$", names(data))]
    df_core <- data[!grepl("_p$", names(data))]

    names(df_peripheral) <- lapply(names(df_peripheral), rename_columns)


    df["start_date"] = start_date
    df["Ground_Truth"] = ground.truth
    df["simplify.directed"] = sd
    df["similarity metric"] = metric
    df["compute_set"] = compute_set

    if (compute_set == "CoreClassification") {
      gt_devs_not_part_of_classification["start_date"] = start_date
      gt_devs_not_part_of_classification["Ground_Truth"] = ground.truth
      gt_devs_not_part_of_classification["simplify.directed"] = sd
      gt_devs_not_part_of_classification["similarity metric"] = metric
      gt_devs_not_part_of_classification["compute_set"] = compute_set

      gt_relative_devs_not_part_of_classification["start_date"] = start_date
      gt_relative_devs_not_part_of_classification["Ground_Truth"] = ground.truth
      gt_relative_devs_not_part_of_classification["simplify.directed"] = sd
      gt_relative_devs_not_part_of_classification["similarity metric"] = metric
      gt_relative_devs_not_part_of_classification["compute_set"] = compute_set

      gt_size["start_date"] = start_date
      gt_size["Ground_Truth"] = ground.truth
      gt_size["simplify.directed"] = sd
      gt_size["similarity metric"] = metric
      gt_size["compute_set"] = compute_set

      core_size["start_date"] = start_date
      core_size["Ground_Truth"] = ground.truth
      core_size["simplify.directed"] = sd
      core_size["similarity metric"] = metric
      core_size["compute_set"] = compute_set

      peripheral_size["start_date"] = start_date
      peripheral_size["Ground_Truth"] = ground.truth
      peripheral_size["simplify.directed"] = sd
      peripheral_size["similarity metric"] = metric
      peripheral_size["compute_set"] = compute_set
    }

    for (x in names(df_core)) {
      comparison_vector <- sort(unlist(df_core[[x]], use.names = FALSE))
      peripheral_classified_vector <- sort(unlist(df_peripheral[[x]], use.names = FALSE))
      peripheral_vector <- sort(setdiff(union(peripheral_classified_vector, main_set), comparison_vector))

      # collect GT people not classified (neither core, nor peripheral)
      if (compute_set == "CoreClassification") {
        all_classified <- union(comparison_vector, peripheral_classified_vector)
        not_classified <- sort(setdiff(main_set, all_classified))
        logging::loginfo(sprintf("[GT %s, Classification %s, Range %s] The following devs are part of the GT but neither classified as core nor as peripheral: %s (%s)",
                                 ground.truth, x, start_date, length(not_classified), paste(not_classified, collapse = ", ")))

        # store the absolute number of not-classified people
        gt_devs_not_part_of_classification[x] = length(not_classified)

        # store the relative number of not-classified people
        gt_relative_devs_not_part_of_classification[x] = (length(not_classified) / length(main_set))

        # store the size of the ground truth
        gt_size[x] = length(main_set)

        # store the size of the core group
        core_size[x] = length(comparison_vector)

        # store the size of the peripheral group
        peripheral_size[x] = length(peripheral_classified_vector)
      }

      if(length(intersect(comparison_vector, peripheral_vector)) != 0) {
        stop()
      }

      if (compute_set != "CoreClassification") {
        core_vector <- comparison_vector
        if (ground.truth == "committer") { # Notice: When ground truth is "committer", we only evaluate "issues" but NOT "issuesInclBorderline"
          comparison_vector <- unlist(gt_table[["issues"]], use.names = FALSE)
        } else if(ground.truth == "issues" || ground.truth == "issuesInclBorderline") {
          comparison_vector <- unlist(gt_table[["committer"]], use.names = FALSE)
        }
        # TODO: is this peripheral_vector really the correct "base" ?
        peripheral_vector <- setdiff(union(core_vector, peripheral_vector), comparison_vector)
      }

      # Iterate over all the similarity measures, compute each and add them to the data.frame
      minimum <- min(length(comparison_vector), length(main_set))
      intersect <- length(intersect(comparison_vector, main_set))
      union <- length(union(comparison_vector, main_set))

      positives <- length(comparison_vector)
      negatives <- length(peripheral_vector)

      true_positives <- length(intersect(comparison_vector, main_set))
      false_positives <- length(setdiff(comparison_vector, main_set))

      true_negatives <- length(setdiff(peripheral_vector, main_set))
      false_negatives <- length(intersect(peripheral_vector, main_set))

      value <- 0

      if (minimum == 0) {
        minimum <- Inf
      }
      if (union == 0) {
        union <- Inf
      }

      switch(
        metric,
        "Jaccard" = {
          value = intersect / union
        },
        "Overlap" = {
          value = (intersect / minimum) * (-1) ^ (length(main_set) <= length(comparison_vector)) # positive if main_set bigger than comparison_vector
        },
        "Intersect" = {
          value = intersect
        },
        "Union" = {
          value = union
        },
        "Precision" = {
          value = true_positives / (true_positives + false_positives)
        },
        "Recall" = {
          value = true_positives / (true_positives + false_negatives)
        },
        "F1" = {
          value = 2 * true_positives / (2 * true_positives + false_negatives + false_positives)

        },
        "Specificity" = {
          value = true_negatives / (true_negatives + false_positives)
        },
        "Balanced Accuracy" = {
          true_positive_rate = true_positives / (true_positives + false_negatives)
          if (is.nan(true_positive_rate)) {
            true_positive_rate = 0
          }

          true_negative_rate = true_negatives / (true_negatives + false_positives)
          if (is.nan(true_negative_rate)) {
            true_negative_rate = 0
          }


          value = (true_positive_rate + true_negative_rate)/
            2
        }
      )
      if (is.nan(value)) {
        value = 0
      }

      df[x] = value
    }

    return(list(df, gt_devs_not_part_of_classification, gt_relative_devs_not_part_of_classification, gt_size, core_size, peripheral_size))
  }

analyze_by_set <-
  function(gt_table,
           netw_output,
           compute_set,
           ground.truth) {
    main_set = unlist(gt_table[ground.truth], use.names = FALSE)

    switch(
      compute_set,
      "Core_Classification" = {
        main_set <- main_set
      },
      # "LOC" = {
      #   main_set <- unlist(netw_output["cc_cochange"], use.names = FALSE)
      # },
      # "CC" = {
      #   main_set <- unlist(netw_output["loc_cochange"], use.names = FALSE)
      # },
      # "LOC" = {
      #   core_cc <- unlist(netw_output["cc_cochange"], use.names = FALSE)
      #   core_loc <-
      #     unlist(netw_output["loc_cochange"], use.names = FALSE)
      #   main_set <- union(core_cc, core_loc)
      # },
      # "Union" = {
      #   core_cc <- unlist(netw_output["cc_cochange"], use.names = FALSE)
      #   core_loc <-
      #     unlist(netw_output["loc_cochange"], use.names = FALSE)
      #   main_set <- union(main_set, union(core_cc, core_loc))
      # },
      # "Intersect" = {
      #   core_cc <- unlist(netw_output["cc_cochange"], use.names = FALSE)
      #   core_loc <-
      #     unlist(netw_output["loc_cochange"], use.names = FALSE)
      #   main_set <- union(main_set, intersect(core_cc, core_loc))
      # },
      "Other_GT" = {
        #main_set <- unlist(gt_table["committer"], use.names = FALSE)
        main_set <- unlist(gt_table[ground.truth], use.names = FALSE)
      }
    )
    return(sort(main_set))
  }

rename_columns <- function(x) {
  return(str_remove(x, "_p"))
}
