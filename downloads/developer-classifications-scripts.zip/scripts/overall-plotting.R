# Define devices
devices = c("pdf", "png", "tikz")
#devices = c("pdf")
# Define projects
casestudies = c(
    "angular",
    "atom",
    "bootstrap",
    "deno",
    "electron",
    "flutter",
    "google-data-transfer-project",
    "jquery",
    "keras",
    "kubernetes",
    "moby",
    "nextcloud",
    "nextjs",
    "nodejs",
    "openssl-github",
    "owncloud-github",
    "react",
    "redux",
    "revealjs",
    "tensorflow",
    "threejs",
    "typescript",
    "vue",
    "vscode",
    "webpack"
)

combine.classification.results(list.of.casestudies = casestudies)

# Create overall plots
plot.all(devices = devices, list.of.casestudies = casestudies)

plot.all.gt.devs.not.part.of.classification(devices = devices, list.of.casestudies = casestudies, relative = FALSE)
plot.all.gt.devs.not.part.of.classification(devices = devices, list.of.casestudies = casestudies, relative = TRUE)

plot.times.between.write.permission.events(devices = devices, list.of.casestudies = casestudies, include.borderline.events = FALSE)
plot.times.between.write.permission.events(devices = devices, list.of.casestudies = casestudies, include.borderline.events = TRUE)

# Define devices
time.ranges = c("3months", "6months", "9months", "12months")
plot.covered.permission.events.by.time(devices = devices, list.of.casestudies = casestudies,
                                       time.ranges = time.ranges, developer.based = "no", include.borderline.events = FALSE)
plot.covered.permission.events.by.time(devices = devices, list.of.casestudies = casestudies,
                                       time.ranges = time.ranges, developer.based = "no", include.borderline.events = TRUE)
plot.covered.permission.events.by.time(devices = devices, list.of.casestudies = casestudies,
                                       time.ranges = time.ranges, developer.based = "max", include.borderline.events = FALSE)
plot.covered.permission.events.by.time(devices = devices, list.of.casestudies = casestudies,
                                       time.ranges = time.ranges, developer.based = "max", include.borderline.events = TRUE)
plot.covered.permission.events.by.time(devices = devices, list.of.casestudies = casestudies,
                                       time.ranges = time.ranges, developer.based = "median", include.borderline.events = FALSE)
plot.covered.permission.events.by.time(devices = devices, list.of.casestudies = casestudies,
                                       time.ranges = time.ranges, developer.based = "median", include.borderline.events = TRUE)
plot.cumulative.distribution.of.events.by.time(devices = devices, list.of.casestudies = casestudies,
                                               developer.based = "no", include.borderline.events = FALSE)
plot.cumulative.distribution.of.events.by.time(devices = devices, list.of.casestudies = casestudies,
                                               developer.based = "no", include.borderline.events = TRUE)
plot.cumulative.distribution.of.events.by.time(devices = devices, list.of.casestudies = casestudies,
                                               developer.based = "max", include.borderline.events = FALSE)
plot.cumulative.distribution.of.events.by.time(devices = devices, list.of.casestudies = casestudies,
                                               developer.based = "max", include.borderline.events = TRUE)
plot.cumulative.distribution.of.events.by.time(devices = devices, list.of.casestudies = casestudies,
                                               developer.based = "median", include.borderline.events = FALSE)
plot.cumulative.distribution.of.events.by.time(devices = devices, list.of.casestudies = casestudies,
                                               developer.based = "median", include.borderline.events = TRUE)
plot.cumulative.distribution.of.events.by.time(devices = devices, list.of.casestudies = casestudies,
                                               developer.based = "avg", include.borderline.events = FALSE)
plot.cumulative.distribution.of.events.by.time(devices = devices, list.of.casestudies = casestudies,
                                               developer.based = "avg", include.borderline.events = TRUE)

plot.sizes.of.gt.and.classified.classes(devices = devices, list.of.casestudies = casestudies)
