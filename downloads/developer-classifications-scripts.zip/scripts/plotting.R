source("./scripts/settings/settings.R")
requireNamespace("tikzDevice")

create_df <- function(gt_devs_not_part_of_classification = FALSE, relative = FALSE) {

  pathing <- file.path(OUTPUT.PATH, CASESTUDY, DISCRETISATION.NAME, "similarity")
  dir.create(pathing, showWarnings = FALSE, recursive = TRUE)
  if (gt_devs_not_part_of_classification) {
    if (relative) {
      df <- readRDS(file = sprintf("%s/gt_relative_devs_not_part_of_classification.rds", pathing))
    } else {
      df <- readRDS(file = sprintf("%s/gt_devs_not_part_of_classification.rds", pathing))
    }
  } else {
    df <- readRDS(file = sprintf("%s/Truth_table_computed.rds", pathing))
  }

  return(df)
}

create_sizes_dfs <- function() {
  pathing <- file.path(OUTPUT.PATH, CASESTUDY, DISCRETISATION.NAME, "similarity")
  dir.create(pathing, showWarnings = FALSE, recursive = TRUE)
  gt_size_df <- readRDS(file = sprintf("%s/gt_size.rds", pathing))
  core_size_df <- readRDS(file = sprintf("%s/core_size.rds", pathing))
  peripheral_size_df <- readRDS(file = sprintf("%s/peripheral_size.rds", pathing))

  return_list = list(gt_size_df, core_size_df, peripheral_size_df)
  names(return_list) = c("gt_size", "core_size", "peripheral_size")
  return(return_list)
}

plotting <- function(df, devices) {

  plot.path = file.path(OUTPUT.PATH, CASESTUDY, DISCRETISATION.NAME, "similarity")

  logging::loginfo("Start Plotting")

  for (ground.truth in GROUND_TRUTHS) {
    for (compute_gt_set in COMPUTE_GT_SET) {
      for (metric in METRICS) {
        logging::loginfo(sprintf("Plotting: GT:%s - GT_SET:%s - METRIC:%s", ground.truth, compute_gt_set, metric))
        #actual_study =  sprintf("%s/%s/%s", CASESTUDY, ground.truth, metric)
        actual_study = sprintf("%s", paste("GT", ground.truth, sep = "-"))

        pathing = file.path(plot.path, "plotted", sep = "") #actual_study, sep = "")
        dir.create(pathing, showWarnings = FALSE, recursive = TRUE)

        # choose only the correct metric for this plot
        df1 <- filter(df, `similarity metric` == metric & compute_set == compute_gt_set & Ground_Truth == ground.truth)
        df2 <- filter(df, compute_set == compute_gt_set & Ground_Truth == ground.truth)

        gt = paste("GT", ground.truth, sep="-")
        comparison_set = paste("ComparisonSet", compute_gt_set, sep="-")

        if (compute_gt_set == "Other_GT") {
          for (simplify.directed in SIMPLIFY.DIRECTED) {
            if (metric == "Jaccard") {
              graph <- plot_graph_Jaccard(data = df1,
                                                   devices = devices,
                                                   similarities = PLOTTING,
                                                   sd = simplify.directed,
                                                   act_study = paste(file.path(actual_study, metric), comparison_set, sep = "_"),
                                                   gt = gt,
                                                   compute_gt_set = comparison_set
              )
            }
            if (metric == "Overlap") {
              graph <- plot_graph_Overlap(data = df1,
                                          devices = devices,
                                          similarities = PLOTTING,
                                          sd = simplify.directed,
                                          act_study = paste(file.path(actual_study, metric), comparison_set, sep = "_"),
                                          gt = gt,
                                          compute_gt_set = comparison_set
              )
            }
            if (metric == "Precision") {
              plot_graph_Precision(data = df2,
                                   devices = devices,
                                   similarities = PLOTTING,
                                   sd = simplify.directed,
                                   act_study = paste(file.path(actual_study, metric), comparison_set, sep = "_"),
                                   gt = gt,
                                   compute_gt_set = comparison_set
              )
            }
            # for (device in devices) {
            #   ggsave(sprintf("%s/%s_%s_%s_%s_comparison.%s", file.path(pathing, gt), gt, comparison_set, simplify.directed, device), width = 5, height = 3, plot = graph, device = device)
            # }
          }

        } else {


          plot_list <- list()
          i <- 1
          for (relation in AUTHOR.RELATION) {
            for (simplify.directed in SIMPLIFY.DIRECTED) {
              if (metric == "Jaccard") {
                plot_list[[i]] <- plot_graph_Jaccard(data = df1,
                                                     devices = devices,
                                                     similarities = PLOTTING,
                                                     sd = simplify.directed,
                                                     author.relation = relation,
                                                     act_study = paste(file.path(actual_study, metric), comparison_set, sep = "_"),
                                                     gt = gt,
                                                     compute_gt_set = comparison_set
                )
                i <- i + 1
              }

              if (metric == "Overlap") {
                plot_list[[i]] <- plot_graph_Overlap(data = df1,
                                                     devices = devices,
                                                     similarities = PLOTTING,
                                                     sd = simplify.directed,
                                                     author.relation = relation,
                                                     act_study = paste(file.path(actual_study, metric), comparison_set, sep = "_"),
                                                     gt = gt,
                                                     compute_gt_set = comparison_set
                )
                i <- i + 1
              }
              if (metric == "Precision") {
                plot_list <- c(plot_list, plot_graph_Precision(data = df2,
                                                               devices = devices,
                                                               similarities = PLOTTING,
                                                               sd = simplify.directed,
                                                               author.relation = relation,
                                                               act_study = paste(file.path(actual_study, metric), comparison_set, sep = "_"),
                                                               gt = gt,
                                                               compute_gt_set = comparison_set)

                )
              }
            }
          }

          if (metric == "Precision") {
            ggarrange(plotlist = plot_list, ncol = 10, nrow = length(plot_list)/10)
            logging::loginfo("Plot summary")
            #if (compute_gt_set == "Core_Classification") {
            #  ggsave(sprintf("%s/%s_%s_%s_%s_comparison.png", file.path(pathing, gt), gt, comparison_set, paste(CASESTUDY, DISCRETISATION.NAME, sep = "-"), metric, device), width = 100, height = 50, units = "cm", limitsize = FALSE)
            #} else {
              for (device in devices) {
                device.name = device
                if (device == 'tikz') device = tikzDevice::tikz
                ggsave(sprintf("%s/%s_%s_%s_%s_comparison.%s", file.path(pathing, gt), gt, comparison_set, paste(CASESTUDY, DISCRETISATION.NAME, sep = "-"), metric, device.name), width = 100, height = 50, limitsize = FALSE, device = device)
              }
            #}
          }

          #})
          # ggarrange(plotlist = plot_list, ncol = 2, nrow = length(plot_list)/2)
          # ggarrange(plotlist = plot_list, ncol = 1, nrow = length(plot_list)/1)
          # logging::loginfo("Plot summary")
          # if (compute_gt_set == "Core_Classification") {
          #   # ggsave(sprintf("%s/%s_%s_comparison.png", pathing, CASESTUDY, metric), width = 10, height = 3 * length(plot_list)/2, limitsize = FALSE)
          #   ggsave(sprintf("%s/%s_%s_comparison.png", pathing, CASESTUDY, metric), width = 5, height = 3 * length(plot_list)/1, limitsize = FALSE)
          #
          # } else {
          #   # ggsave(sprintf("%s/%s_%s_SD_comparison.png", pathing, gt, comparison_set), width = 10, height = 3 * length(plot_list)/2, limitsize = FALSE)
          #   ggsave(sprintf("%s/%s_%s_SD_comparison.png", pathing, gt, comparison_set), width = 5, height = 3 * length(plot_list)/1, limitsize = FALSE)
          #
          # }
        }
      }
    }
  }
}

display_main_table <- function() {
  file_path = paste(OUTPUT.PATH, "/", CASESTUDY, "/", sep = "")
  df <- readRDS(paste(file_path, "main_table.rds", sep = ""))

  new_df <-data.frame()

  main_set <- unlist(df$issue_reviewed.name, use.names = FALSE)

  new_df <- cbind(new_df, main_set)
}

plot_graph_Precision <- function(dataframe = data.frame(), devices = c("png", "pdf"), similarities = c("network_degree", "network_eigen", "network_hierarchy", "commit_count", "loc_count"), sd = "FF", author.relation = c("cochange", "issue", "mail"), act_study = "", gt = "", compute_gt_set = "") {

  plot.path = file.path(OUTPUT.PATH, CASESTUDY, DISCRETISATION.NAME, "similarity")

  #actual_study =  sprintf("%s-issues-Precision", CASESTUDY)
  pathing_without_casestudy = file.path(plot.path, "plotted", act_study, sep = "")
  dir.create(pathing_without_casestudy, showWarnings = FALSE, recursive = TRUE)
  pathing = paste0(pathing_without_casestudy) #, CASESTUDY)

  df_all <- filter(dataframe, simplify.directed == sd & `similarity metric` != "Jaccard" & `similarity metric` != "Overlap" & `similarity metric` != "Intersect" & `similarity metric` != "Union")

  df_precision <- filter(dataframe, simplify.directed == sd & `similarity metric` == "Precision")
  # df_recall <- filter(dataframe, simplify.directed == sd & `similarity metric` == "Recall")

  df_before = df_precision

  graph <- ggplot(data = df_before, aes(x = start_date))

  sd.printable = switch(sd,
    "FT" = "unsimplified directed",
    "FF" = "unsimplified undirected",
    "TF" = "simplified undirected",
    "TT" = "simplified directed"
  )

  value_list <- c()
  label_list <- c()
  options(tikzMetricPackages = c("\\usepackage[utf8]{inputenc}","\\usepackage[T1]{fontenc}", "\\usetikzlibrary{calc}", "\\usepackage{amssymb}"))
  graph <- graph + xlab('Start Date') + ylab('Similarity to Ground Truth') +
    expand_limits(y = c(0, 1.0)) +
    theme(axis.text.x = element_text(angle = 90), plot.title = element_text(size = 10))

  # start with cochange
  if (all(author.relation == "cochange")) {
      graph_nd <- graph +
        geom_col(data = df_all, aes(y = nd_cochange, fill = `similarity metric`), position = position_dodge()) +
        ggtitle(sprintf("Degree %s", paste(paste(author.relation, collapse = "-"), sd.printable, sep = " ")))

      for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%sND_Precision_%s_%s_%s.%s", pathing, paste(paste(author.relation, collapse = "-"), sd, gt, compute_gt_set, sep = "_"), CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
      }

      graph_ne <- graph +
        geom_col(data = df_all, aes(y = ne_cochange, fill = `similarity metric`), position = position_dodge()) +
        ggtitle(sprintf("Eigenvector %s", paste(paste(author.relation, collapse = "-"), sd.printable, sep = " ")))

      for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%sNE_Precision_%s_%s_%s.%s", pathing, paste(paste(author.relation, collapse = "-"), sd, gt, compute_gt_set, sep = "_"), CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
      }

      graph_nh <- graph +
        geom_col(data = df_all, aes(y = nh_cochange, fill = `similarity metric`), position = position_dodge()) +
        ggtitle(sprintf("Hierarchy %s", paste(paste(author.relation, collapse = "-"), sd.printable, sep = " ")))

      for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%sNH_Precision_%s_%s_%s.%s", pathing, paste(paste(author.relation, collapse = "-"), sd, gt, compute_gt_set, sep = "_"), CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
      }

      graph_cc <- graph +
        geom_col(data = df_all, aes(y = cc_cochange, fill = `similarity metric`), position = position_dodge()) +
        ggtitle(sprintf("Commit Count"))

      for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%sCC_Precision_%s_%s_%s_%s.%s", pathing, gt, compute_gt_set, CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
      }

      graph_loc <- graph +
        geom_col(data = df_all, aes(y = loc_cochange, fill = `similarity metric`), position = position_dodge()) +
        ggtitle(sprintf("Lines Of Code"))

      for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%sLOC_Precision_%s_%s_%s_%s.%s", pathing, gt, compute_gt_set, CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
      }

      ggarrange(graph_nd, graph_ne, graph_nh, graph_cc, graph_loc, ncol = 1, nrow = 5)
      for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%s%s_Precision_%s_%s.%s", pathing, paste(paste(author.relation, collapse = "-"), sd, gt, compute_gt_set, sep = "_"), CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 15, limitsize = FALSE, device = device)
      }
  }
  # start with issues
  if (all(author.relation == "issue")) {
      graph_nd <- graph +
        geom_col(data = df_all, aes(y = nd_issue, fill = `similarity metric`), position = position_dodge()) +
        ggtitle(sprintf("Degree %s", paste(paste(author.relation, collapse = "-"), sd.printable, sep = " ")))

      for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%sND_Precision_%s_%s_%s.%s", pathing, paste(paste(author.relation, collapse = "-"), sd, gt, compute_gt_set, sep = "_"), CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
      }

      graph_ne <- graph +
        geom_col(data = df_all, aes(y = ne_issue, fill = `similarity metric`), position = position_dodge()) +
        ggtitle(sprintf("Eigenvector %s", paste(paste(author.relation, collapse = "-"), sd.printable, sep = " ")))

      for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%sNE_Precision_%s_%s_%s.%s", pathing, paste(paste(author.relation, collapse = "-"), sd, gt, compute_gt_set, sep = "_"), CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
      }

      graph_nh <- graph +
        geom_col(data = df_all, aes(y = nh_issue, fill = `similarity metric`), position = position_dodge()) +
        ggtitle(sprintf("Hierarchy %s", paste(paste(author.relation, collapse = "-"), sd.printable, sep = " ")))

      for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%sNH_Precision_%s_%s_%s.%s", pathing, paste(paste(author.relation, collapse = "-"), sd, gt, compute_gt_set, sep = "_"), CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
      }

      graph_cc <- graph +
        geom_col(data = df_all, aes(y = cc_issue, fill = `similarity metric`), position = position_dodge()) +
        ggtitle(sprintf("Commit Count"))

      for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%sCC_Precision_%s_%s_%s_%s.%s", pathing, gt, compute_gt_set, CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
      }

      graph_loc <- graph +
        geom_col(data = df_all, aes(y = loc_issue, fill = `similarity metric`), position = position_dodge()) +
        ggtitle(sprintf("Lines Of Code"))

      for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%sLOC_Precision_%s_%s_%s_%s.%s", pathing, gt, compute_gt_set, CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
      }

      ggarrange(graph_nd, graph_ne, graph_nh, graph_cc, graph_loc, ncol = 1, nrow = 5)
      for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%s%s_Precision_%s_%s.%s", pathing, paste(paste(author.relation, collapse = "-"), sd, gt, compute_gt_set, sep = "_"), CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 15, limitsize = FALSE, device = device)
      }
  }
  # start with mail
  if (all(author.relation == "mail")) {
      graph_nd <- graph +
        geom_col(data = df_all, aes(y = nd_mail, fill = `similarity metric`), position = position_dodge()) +
        ggtitle(sprintf("Degree %s", paste(paste(author.relation, collapse = "-"), sd.printable, sep = " ")))

      for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%sND_Precision_%s_%s_%s.%s", pathing, paste(paste(author.relation, collapse = "-"), sd, gt, compute_gt_set, sep = "_"), CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
      }

      graph_ne <- graph +
        geom_col(data = df_all, aes(y = ne_mail, fill = `similarity metric`), position = position_dodge()) +
        ggtitle(sprintf("Eigenvector %s", paste(paste(author.relation, collapse = "-"), sd.printable, sep = " ")))

      for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%sNE_Precision_%s_%s_%s.%s", pathing, paste(paste(author.relation, collapse = "-"), sd, gt, compute_gt_set, sep = "_"), CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
      }

      graph_nh <- graph +
        geom_col(data = df_all, aes(y = nh_mail, fill = `similarity metric`), position = position_dodge()) +
        ggtitle(sprintf("Hierarchy %s", paste(paste(author.relation, collapse = "-"), sd.printable, sep = " ")))

      for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%sNH_Precision_%s_%s_%s.%s", pathing, paste(paste(author.relation, collapse = "-"), sd, gt, compute_gt_set, sep = "_"), CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
      }

      graph_cc <- graph +
        geom_col(data = df_all, aes(y = cc_mail, fill = `similarity metric`), position = position_dodge()) +
        ggtitle(sprintf("Commit Count"))

      for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%sCC_Precision_%s_%s_%s_%s.%s", pathing, gt, compute_gt_set, CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
      }

      graph_loc <- graph +
        geom_col(data = df_all, aes(y = loc_mail, fill = `similarity metric`), position = position_dodge()) +
        ggtitle(sprintf("Lines Of Code"))

      for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%sLOC_Precision_%s_%s_%s_%s.%s", pathing, gt, compute_gt_set, CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
      }

      ggarrange(graph_nd, graph_ne, graph_nh, graph_cc, graph_loc, ncol = 1, nrow = 5)
      for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%s%s_Precision_%s_%s.%s", pathing, paste(paste(author.relation, collapse = "-"), sd, gt, compute_gt_set, sep = "_"), CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 15, limitsize = FALSE, device = device)
      }
  }
  # start with cochange issue
  if (all(author.relation == c("cochange", "issue"))) {
    graph_nd <- graph +
      geom_col(data = df_all, aes(y = nd_co_is, fill = `similarity metric`), position = position_dodge()) +
      ggtitle(sprintf("Degree %s", paste(paste(author.relation, collapse = "-"), sd.printable, sep = " ")))

    for (device in devices) {
      device.name = device
      if (device == 'tikz') device = tikzDevice::tikz
      ggsave(sprintf("%sND_Precision_%s_%s_%s.%s", pathing, paste(paste(author.relation, collapse = "-"), sd, gt, compute_gt_set, sep = "_"), CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
    }

    graph_ne <- graph +
      geom_col(data = df_all, aes(y = ne_co_is, fill = `similarity metric`), position = position_dodge()) +
      ggtitle(sprintf("Eigenvector %s", paste(paste(author.relation, collapse = "-"), sd.printable, sep = " ")))

    for (device in devices) {
      device.name = device
      if (device == 'tikz') device = tikzDevice::tikz
      ggsave(sprintf("%sNE_Precision_%s_%s_%s.%s", pathing, paste(paste(author.relation, collapse = "-"), sd, gt, compute_gt_set, sep = "_"), CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
    }

    graph_nh <- graph +
      geom_col(data = df_all, aes(y = nh_co_is, fill = `similarity metric`), position = position_dodge()) +
      ggtitle(sprintf("Hierarchy %s", paste(paste(author.relation, collapse = "-"), sd.printable, sep = " ")))

    for (device in devices) {
      device.name = device
      if (device == 'tikz') device = tikzDevice::tikz
      ggsave(sprintf("%sNH_Precision_%s_%s_%s.%s", pathing, paste(paste(author.relation, collapse = "-"), sd, gt, compute_gt_set, sep = "_"), CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
    }

    graph_cc <- graph +
      geom_col(data = df_all, aes(y = cc_co_is, fill = `similarity metric`), position = position_dodge()) +
      ggtitle(sprintf("Commit Count"))

    for (device in devices) {
      device.name = device
      if (device == 'tikz') device = tikzDevice::tikz
      ggsave(sprintf("%sCC_Precision_%s_%s_%s_%s.%s", pathing, gt, compute_gt_set, CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
    }

    graph_loc <- graph +
      geom_col(data = df_all, aes(y = loc_co_is, fill = `similarity metric`), position = position_dodge()) +
      ggtitle(sprintf("Lines Of Code"))

    for (device in devices) {
      device.name = device
      if (device == 'tikz') device = tikzDevice::tikz
      ggsave(sprintf("%sLOC_Precision_%s_%s_%s_%s.%s", pathing, gt, compute_gt_set, CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
    }

    ggarrange(graph_nd, graph_ne, graph_nh, graph_cc, graph_loc, ncol = 1, nrow = 5)
    for (device in devices) {
      device.name = device
      if (device == 'tikz') device = tikzDevice::tikz
      ggsave(sprintf("%s%s_Precision_%s_%s.%s", pathing, paste(paste(author.relation, collapse = "-"), sd, gt, compute_gt_set, sep = "_"), CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 15, limitsize = FALSE, device = device)
    }
  }
  #start with cochange mail
  if(all(author.relation == c("cochange", "mail"))){
      graph_nd <- graph +
        geom_col(data = df_all, aes(y = nd_co_ma, fill = `similarity metric`), position = position_dodge()) +
        ggtitle(sprintf("Degree %s", paste(paste(author.relation, collapse = "-"), sd.printable, sep = " ")))

      for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%sND_Precision_%s_%s_%s.%s", pathing, paste(paste(author.relation, collapse = "-"), sd, gt, compute_gt_set, sep = "_"), CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
      }

      graph_ne <- graph +
        geom_col(data = df_all, aes(y = ne_co_ma, fill = `similarity metric`), position = position_dodge()) +
        ggtitle(sprintf("Eigenvector %s", paste(paste(author.relation, collapse = "-"), sd.printable, sep = " ")))

      for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%sNE_Precision_%s_%s_%s.%s", pathing, paste(paste(author.relation, collapse = "-"), sd, gt, compute_gt_set, sep = "_"), CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
      }

      graph_nh <- graph +
        geom_col(data = df_all, aes(y = nh_co_ma, fill = `similarity metric`), position = position_dodge()) +
        ggtitle(sprintf("Hierarchy %s", paste(paste(author.relation, collapse = "-"), sd.printable, sep = " ")))

      for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%sNH_Precision_%s_%s_%s.%s", pathing, paste(paste(author.relation, collapse = "-"), sd, gt, compute_gt_set, sep = "_"), CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
      }

      graph_cc <- graph +
        geom_col(data = df_all, aes(y = cc_co_ma, fill = `similarity metric`), position = position_dodge()) +
        ggtitle(sprintf("Commit Count"))

      for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%sCC_Precision_%s_%s_%s_%s.%s", pathing, gt, compute_gt_set, CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
      }

      graph_loc <- graph +
        geom_col(data = df_all, aes(y = loc_co_ma, fill = `similarity metric`), position = position_dodge()) +
        ggtitle(sprintf("Lines Of Code"))

      for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%sLOC_Precision_%s_%s_%s_%s.%s", pathing, gt, compute_gt_set, CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
      }
  }
  # start with issue mail
  if (all(author.relation == c("issue", "mail"))) {
      graph_nd <- graph +
        geom_col(data = df_all, aes(y = nd_is_ma, fill = `similarity metric`), position = position_dodge()) +
        ggtitle(sprintf("Degree %s", paste(paste(author.relation, collapse = "-"), sd.printable, sep = " ")))

      for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%sND_Precision_%s_%s_%s.%s", pathing, paste(paste(author.relation, collapse = "-"), sd, gt, compute_gt_set, sep = "_"), CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
      }

      graph_ne <- graph +
        geom_col(data = df_all, aes(y = ne_is_ma, fill = `similarity metric`), position = position_dodge()) +
        ggtitle(sprintf("Eigenvector %s", paste(paste(author.relation, collapse = "-"), sd.printable, sep = " ")))

      for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%sNE_Precision_%s_%s_%s.%s", pathing, paste(paste(author.relation, collapse = "-"), sd, gt, compute_gt_set, sep = "_"), CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
      }

      graph_nh <- graph +
        geom_col(data = df_all, aes(y = nh_is_ma, fill = `similarity metric`), position = position_dodge()) +
        ggtitle(sprintf("Hierarchy %s", paste(paste(author.relation, collapse = "-"), sd.printable, sep = " ")))

      for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%sNH_Precision_%s_%s_%s.%s", pathing, paste(paste(author.relation, collapse = "-"), sd, gt, compute_gt_set, sep = "_"), CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
      }

      graph_cc <- graph +
        geom_col(data = df_all, aes(y = cc_is_ma, fill = `similarity metric`), position = position_dodge()) +
        ggtitle(sprintf("Commit Count"))

      for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%sCC_Precision_%s_%s_%s_%s.%s", pathing, gt, compute_gt_set, CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
      }

      graph_loc <- graph +
        geom_col(data = df_all, aes(y = loc_is_ma, fill = `similarity metric`), position = position_dodge()) +
        ggtitle(sprintf("Lines Of Code"))

      for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%sLOC_Precision_%s_%s_%s_%s.%s", pathing, gt, compute_gt_set, CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
      }
  }
  # start with cochange issue mail
  if (all(author.relation == c("cochange", "issue", "mail"))) {
      graph_nd <- graph +
        geom_col(data = df_all, aes(y = nd_co_is_ma, fill = `similarity metric`), position = position_dodge()) +
        ggtitle(sprintf("Degree %s", paste(paste(author.relation, collapse = "-"), sd.printable, sep = " ")))

      for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%sND_Precision_%s_%s_%s.%s", pathing, paste(paste(author.relation, collapse = "-"), sd, gt, compute_gt_set, sep = "_"), CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
      }

      graph_ne <- graph +
        geom_col(data = df_all, aes(y = ne_co_is_ma, fill = `similarity metric`), position = position_dodge()) +
        ggtitle(sprintf("Eigenvector %s", paste(paste(author.relation, collapse = "-"), sd.printable, sep = " ")))

      for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%sNE_Precision_%s_%s_%s.%s", pathing, paste(paste(author.relation, collapse = "-"), sd, gt, compute_gt_set, sep = "_"), CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
      }

      graph_nh <- graph +
        geom_col(data = df_all, aes(y = nh_co_is_ma, fill = `similarity metric`), position = position_dodge()) +
        ggtitle(sprintf("Hierarchy %s", paste(paste(author.relation, collapse = " "), sd.printable, sep = " ")))

      for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%sNH_Precision_%s_%s_%s.%s", pathing, paste(paste(author.relation, collapse = "-"), sd, gt, compute_gt_set, sep = "_"), CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
      }

      graph_cc <- graph +
        geom_col(data = df_all, aes(y = cc_co_is_ma, fill = `similarity metric`), position = position_dodge()) +
        ggtitle(sprintf("Commit Count"))

      for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%sCC_Precision_%s_%s_%s_%s.%s", pathing, gt, compute_gt_set, CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
      }

      graph_loc <- graph +
        geom_col(data = df_all, aes(y = loc_co_is_ma, fill = `similarity metric`), position = position_dodge()) +
        ggtitle(sprintf("Lines Of Code"))

      for (device in devices) {
        device.name = device
        if (device == 'tikz') device = tikzDevice::tikz
        ggsave(sprintf("%sLOC_Precision_%s_%s_%s_%s.%s", pathing, gt, compute_gt_set, CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
      }

}

  ggarrange(graph_nd, graph_ne, graph_nh, graph_cc, graph_loc, ncol = 1, nrow = 5)
  for (device in devices) {
    device.name = device
    if (device == 'tikz') device = tikzDevice::tikz
    ggsave(sprintf("%s%s_Precision_%s_%s.%s", pathing, paste(paste(author.relation, collapse = "-"), sd, gt, compute_gt_set, sep = "_"), CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 15, limitsize = FALSE, device = device)
  }

  return(list(graph_nd, graph_ne, graph_nh, graph_cc, graph_loc))
}

plot_graph_Jaccard <- function(data = data.frame(), devices = c("png", "pdf"), similarities = c("network_degree", "network_eigen", "network_hierarchy", "commit_count", "loc_count"), sd = "FF", author.relation = c("cochange", "issue", "mail"), act_study = "", gt = "", compute_gt_set = "") {
  df <- filter(data, simplify.directed == sd)
  graph <- ggplot(data = df, aes(x = start_date))

  value_list <- c()
  label_list <- c()

  graph <- graph + xlab('Start Date') + ylab('Similarity to Ground Truth') +
    expand_limits(y = c(0.0, 1.0)) +
    theme(axis.text.x = element_text(angle = 90), plot.title = element_text(size = 10)) +
    ggtitle(sprintf("Simplify = %s, Directed = %s %s", substr(sd, 1, 1), substr(sd, 2, 2), paste(author.relation, sep = "", collapse = " ")))

  ifelse(all(author.relation == "cochange"), df <- select(df, nd_cochange, ne_cochange, nh_cochange, cc_cochange, loc_cochange),
         ifelse(all(author.relation == "issue"), df <- select(df, nd_issue, ne_issue, nh_issue, cc_issue, loc_issue),
                ifelse(all(author.relation == "mail"), df <- select(df, nd_mail, ne_mail, nh_mail, cc_mail, loc_mail),
                       ifelse(all(author.relation == c("cochange", "issue")), df <- select(df, nd_co_is, ne_co_is, nh_co_is, cc_co_is, loc_co_is),
                              ifelse(all(author.relation == c("cochange", "mail")), df <- select(df, nd_co_ma, ne_co_ma, nh_co_ma, cc_co_ma, loc_co_ma),
                                     ifelse(all(author.relation == c("issue", "mail")), df <- select(df, nd_is_ma, ne_is_ma, nh_is_ma, cc_is_ma, loc_is_ma),
                                            ifelse(all(author.relation == c("cochange", "issue", "mail")), df <- select(df, nd_co_is_ma, ne_co_is_ma, nh_co_is_ma, cc_co_is_ma, loc_co_is_ma),
                                                   "default"
                                            )))))))
  if("commit_count" %in% similarities) {
    graph <- graph + geom_line(aes(y = df[[4]], color = "black", group = 1))
    label_list <- c(label_list, "Commit Count")
    value_list <- c(value_list, black = "black")
  }
  if("network_hierarchy" %in% similarities) {
    graph <- graph + geom_line(aes(y = df[[3]], color = "blue", group = 1))
    label_list <- c(label_list, "Hierarchy")
    value_list <- c(value_list, blue = "blue")
  }
  if("network_eigen" %in% similarities) {
    graph <- graph + geom_line(aes(y = df[[2]], color = "green", group = 1))
    label_list <- c(label_list, "Eigenvector")
    value_list <- c(value_list, green = "green")
  }
  if("network_degree" %in% similarities) {
    graph <- graph + geom_line(aes(y = df[[1]], color = "red", group = 1))
    label_list <- c(label_list, "Degree")
    value_list <- c(value_list, red = "red")
  }
  if("loc_count" %in% similarities) {
    graph <- graph + geom_line(aes(y = df[[5]], color = "yellow", group = 1))
    label_list <- c(label_list, "LoC Count")
    value_list <- c(value_list, yellow = "yellow")
  }

  graph <- graph +
    scale_colour_manual(name = "Classification",
                        values = value_list,
                        labels = label_list)

  plot.path = file.path(OUTPUT.PATH, CASESTUDY, DISCRETISATION.NAME, "similarity")

  pathing = file.path(plot.path, "plotted", act_study, sep = "")
  dir.create(pathing, showWarnings = FALSE, recursive = TRUE)

  for (device in devices) {
    device.name = device
    if (device == 'tikz') device = tikzDevice::tikz
    ggsave(sprintf("%s/%s_%s_%s_%s_%s_%s.%s", pathing, sd, gt, compute_gt_set, paste(author.relation, sep = "", collapse = "-"), CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
  }

  return(graph)
}

plot_graph_Overlap <- function(data = data.frame(), devices = c("png", "pdf"), similarities = c("network_degree", "network_eigen", "network_hierarchy", "commit_count", "loc_count"), sd = "FF", author.relation = c("cochange", "issue", "mail"), act_study = "", gt = "", compute_gt_set = "") {
  df <- filter(data, simplify.directed == sd)
  graph <- ggplot(data = df, aes(x = start_date))

  value_list <- c()
  label_list <- c()

  graph <- graph + xlab('Start Date') + ylab('Similarity to Ground Truth') +
    expand_limits(y = c(-1.0, 1.0)) +
    theme(axis.text.x = element_text(angle = 90), plot.title = element_text(size = 10)) +
    ggtitle(sprintf("Simplify = %s, Directed = %s %s", substr(sd, 1, 1), substr(sd, 2, 2), paste(author.relation, sep = "", collapse = " ")))

  ifelse(all(author.relation == "cochange"), df <- select(df, nd_cochange, ne_cochange, nh_cochange, cc_cochange, loc_cochange),
         ifelse(all(author.relation == "issue"), df <- select(df, nd_issue, ne_issue, nh_issue, cc_issue, loc_issue),
                ifelse(all(author.relation == "mail"), df <- select(df, nd_mail, ne_mail, nh_mail, cc_mail, loc_mail),
                       ifelse(all(author.relation == c("cochange", "issue")), df <- select(df, nd_co_is, ne_co_is, nh_co_is, cc_co_is, loc_co_is),
                              ifelse(all(author.relation == c("cochange", "mail")), df <- select(df, nd_co_ma, ne_co_ma, nh_co_ma, cc_co_ma, loc_co_ma),
                                     ifelse(all(author.relation == c("issue", "mail")), df <- select(df, nd_is_ma, ne_is_ma, nh_is_ma, cc_is_ma, loc_is_ma),
                                            ifelse(all(author.relation == c("cochange", "issue", "mail")), df <- select(df, nd_co_is_ma, ne_co_is_ma, nh_co_is_ma, cc_co_is_ma, loc_co_is_ma),
                                                   "default"
                                            )))))))
  if("commit_count" %in% similarities) {
    graph <- graph + geom_line(aes(y = df[[4]], color = "black", group = 1))
    label_list <- c(label_list, "Commit Count")
    value_list <- c(value_list, black = "black")
  }
  if("network_hierarchy" %in% similarities) {
    graph <- graph + geom_line(aes(y = df[[3]], color = "blue", group = 1))
    label_list <- c(label_list, "Hierarchy")
    value_list <- c(value_list, blue = "blue")
  }
  if("network_eigen" %in% similarities) {
    graph <- graph + geom_line(aes(y = df[[2]], color = "green", group = 1))
    label_list <- c(label_list, "Eigenvector")
    value_list <- c(value_list, green = "green")
  }
  if("network_degree" %in% similarities) {
    graph <- graph + geom_line(aes(y = df[[1]], color = "red", group = 1))
    label_list <- c(label_list, "Degree")
    value_list <- c(value_list, red = "red")
  }
  if("loc_count" %in% similarities) {
    graph <- graph + geom_line(aes(y = df[[5]], color = "yellow", group = 1))
    label_list <- c(label_list, "LoC Count")
    value_list <- c(value_list, yellow = "yellow")
  }

  graph <- graph +
    scale_colour_manual(name = "Classification",
                        values = value_list,
                        labels = label_list)

  plot.path = file.path(OUTPUT.PATH, CASESTUDY, DISCRETISATION.NAME, "similarity")

  pathing = file.path(plot.path, "plotted", act_study, sep = "")
  dir.create(pathing, showWarnings = FALSE, recursive = TRUE)
  for (device in devices) {
    device.name = device
    if (device == 'tikz') device = tikzDevice::tikz
    ggsave(sprintf("%s/%s_%s_%s_%s_%s_%s.%s", pathing, sd, gt, compute_gt_set, paste(author.relation, sep = "", collapse = "-"), CASESTUDY, DISCRETISATION.NAME, device.name), width = 5, height = 3, device = device)
  }

  return(graph)
}

avgs <- function(data = data.frame(), sd = "FF", act_study = "", ground_truth = "", compute_gt_set = "") {
  df <- filter(data, simplify.directed == sd)

  vec <- list()
  i <- 1
  for (x in names(df)) {
    vec[i] <- mean(df[[x]], na.rm = TRUE)
    i <- i + 1
  }
  df <- rbind(df, vec)
  df <- filter(df, is.na(df$GT))

  plot.path = file.path(OUTPUT.PATH, CASESTUDY, DISCRETISATION.NAME, "similarity")

  pathing = file.path(plot.path, "plotted", act_study, sep = "")
  dir.create(pathing, showWarnings = FALSE, recursive = TRUE)

  png(sprintf("%s/%s_%s_%s_%s_%s.png", pathing, sd, ground_truth, compute_gt_set, CASESTUDY, DISCRETISATION.NAME), height = 50, width = 4096)
  grid.table(df)
  dev.off()

  pdf(sprintf("%s/%s_%s_%s_%s_%s.pdf", pathing, sd, ground_truth, compute_gt_set, CASESTUDY, DISCRETISATION.NAME), height = 50, width = 4096)
  grid.table(df)
  dev.off()
}

