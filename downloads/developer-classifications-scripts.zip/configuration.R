# GLOBAL VARIABLES AS CONFIGURATION FOR ALL SCRIPTS

## / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / /
## LOAD NEEDED LIBRARIES

requireNamespace("parallel") # for parallel computation
requireNamespace("logging") # for logging

## / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / /
## CONFIGURE PARALLELIZATION

# If you want to use multiple cores, you have to comment in the following line,
# which takes max cores - 1. If you need less or more cores, please adapt appropriately.

options(mc.cores = (max(4L, parallel::detectCores(), na.rm = TRUE) - 1))

## / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / /
## DEFAULT CONFIGURATION (USED ONLY IF NO COMMAND LINE ARGUMENTS ARE USED)

# CONFIGURE PATH TO INPUT DATA

DATA.PATH <- "codeface-data"



# CONFIGURE OUTPUT PATH

OUTPUT.PATH <- "./plots"
dir.create(OUTPUT.PATH, showWarnings = FALSE, recursive = TRUE)

# CONFIGURE ANALYSIS

ARTIFACT.RELATION <- "cochange" # cochange, callgraph
ANALYSIS.RANGE.TYPE <- "threemonth" # threemonth, releases

# CASESTUDY = c(
    "angular",
    "google-data-transfer-project",
    "openssl-github",
    "owncloud-github",
    "nextcloud",
    "nodejs",
    "keras",
    "revealjs",
    "deno",
    "redux",
    "threejs",
    "vue",
    "webpack",
    "nextjs",
    "electron",
    "react",
    "jquery",
    "typescript",
    "atom",
    "bootstrap",
    "moby",
    "flutter",
    "tensorflow",
    "vscode",
# )

ARTIFACT = c(
  "file"#,
  #"function",
  #"feature",
  #"mail"
)

# set appropriate parameters for the analysis method
## / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / /
## GENERAL CONFIGURATION (REGARDLESS OF COMMAND LINE ARGS ARE USED OR NOT)

# CONFIGURE PLOTS

# paper size
PAPER.WIDTH = 1191
PAPER.HEIGHT = 842

# CONFIGURE DISCRETISATION

# whether networks should be constructed only containing authors present in the bipartite artifact relation
# one of "all", "onlyCurrentContributors", "onlyPreviousContributors"
NETWORKS.AUTHORS <- "all" # "onlyCurrentContributors", "onlyPreviousContributors"

# whether the splitting is performed using a sliding-window approach
SLIDING.WINDOW <- FALSE

# whether to discretise the global network based on fixed time windows or activity
TYPE.OF.DISCRETISATION <- "TIME_BASED" # "TIME_BASED", "ACTIVITY_EDGE_WINDOW_BASED", "ACTIVITY_EDGE_AMOUNT_BASED",
                                       # "ACTIVITY_DATA_WINDOW_BASED", "ACTIVITY_DATA_AMOUNT_BASED"

# length of the observation windows, used for the time-based discretisation of the global network
TIME.PERIOD <- "6 months" # given in second(s), minute(s), hour(s), day(s), month(s) or year(s)

# number of observation windows for the activity-based (window) discretisation
NR.OF.WINDOWS <- 6 # a positive integer or one of the constants in util.R

# number of edges per network for the activity-based (edge) discretisation
NR.OF.EDGES <- 15000 # a positive integer

# amount of activity per range (based on data only) for the activity-based discretisation
NR.OF.ACTIVITY <- 1000 # a positive integer

## / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / /
# DO NOT CHANGE THE FOLLOWING SETTINGS
## / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / /

options(stringsAsFactors = FALSE)

## CONFIGURATION VIA COMMAND LINE ARGUMENTS
if (!exists("cargs"))
  cargs = commandArgs(trailingOnly = TRUE)

if (length(cargs) > 1) {
  source("configuration-cli.R")

  ## command-line arguments
  cli.parser = create.cli.parser()
  cli.args = cli.parser$parse_args()

  CASESTUDY = cli.args[["casestudy"]]
  ANALYSIS = cli.args[["analysis"]]
  TIME.PERIOD = cli.args[["time_period"]]
  SLIDING.WINDOW = cli.args[["sliding_window"]]
  ARTIFACT.RELATION = cli.args[["artifact_relation"]]
  AUTHOR.RELATION = cli.args[["author_relation"]]
  ANALYSIS.RANGE.TYPE = cli.args[["analysis_range_type"]]
  NETWORKS.AUTHORS = cli.args[["networks_authors"]]
  DATA.PATH = cli.args[["codeface_data"]]
  OUTPUT.PATH = cli.args[["output"]]

  # set appropriate parameters for the analysis method
  if(ANALYSIS == "mail"){
    ARTIFACT <- "feature"
    AUTHOR.RELATION <- "mail"
  }else{
    ARTIFACT <- ANALYSIS # function, feature, or file
    #AUTHOR.RELATION <- "cochange"
  }
} else {
  CASESTUDY = cargs
  print(cargs)
}

# Reduce parallelism for huge projects
if(CASESTUDY == "vscode" || CASESTUDY == "tensorflow" || CASESTUDY == "moby") {
  options(mc.cores = 10L)
} else if (CASESTUDY == "nodejs") {
  options(mc.cores = 4L)
} else if (CASESTUDY == "kubernetes") {
  options(mc.cores = 1L)
} else if (CASESTUDY == "flutter") {
  options(mc.cores = 1L)
}

## CONFIGURATIONS BASED ON PREVIOUS CONFIGURATIONS

# string representation of the discretisation, used for file names
DISCRETISATION.NAME <- switch(TYPE.OF.DISCRETISATION,
                              "ACTIVITY_EDGE_AMOUNT_BASED" = paste0(NR.OF.EDGES, "edgesPerActivityWindow"),
                              "ACTIVITY_DATA_AMOUNT_BASED" = paste0(NR.OF.ACTIVITY, "activitiesPerActivityWindow"),
                              "ACTIVITY_EDGE_WINDOW_BASED" = paste0(NR.OF.WINDOWS, "edgeActivityWindows"),
                              "ACTIVITY_DATA_WINDOW_BASED" = paste0(NR.OF.WINDOWS, "dataActivityWindows"),
                              "TIME_BASED" = paste0(gsub(" ", "", TIME.PERIOD), "PerTimeWindow"))

if(SLIDING.WINDOW) {
  DISCRETISATION.NAME <- paste(DISCRETISATION.NAME, "slidingWindow", sep="_")
}

if(NETWORKS.AUTHORS != "all") {
  DISCRETISATION.NAME <- paste(DISCRETISATION.NAME, NETWORKS.AUTHORS, sep="_")
}

# split basis for data splitting is based on configured author relation
SPLIT.BASIS <- "commits" # "mails" # "issues"

# determine subdirectory for output (use "global" when reading "threemonth" data from Codeface)
OUTPUT.PATH.RANGE.TYPE <- ifelse(ANALYSIS.RANGE.TYPE=="threemonth", "global", ANALYSIS.RANGE.TYPE)
OUTPUT.PATH <- file.path(OUTPUT.PATH, OUTPUT.PATH.RANGE.TYPE)

## LOGGING for submodule coronet (using the logging package)

# configuration
library(logging)
LOG.LEVEL = "INFO"

# initialize logging package (stdout + log file)
logging::logReset()
logging::basicConfig(level = LOG.LEVEL)
